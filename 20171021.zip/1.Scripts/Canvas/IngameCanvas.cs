﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IngameCanvas : MonoBehaviour {

	// Use this for initialization
	void Awake () {
		


	}

    //public bool B_PanelTouch = false;

    //public void btn_PanelTouch()
    //{

     

    //}


    bool BchangeElement = true;

    // 속성을 바꿔준다. 
    public void changeElement()
    {
     

        BchangeElement = !BchangeElement;
        if (BchangeElement)
            PlayerMgr.player.m_element = PlayerMgr.player.SwapElement[0];
       else
            PlayerMgr.player.m_element = PlayerMgr.player.SwapElement[1];

        PlayerMgr.player.SetElement();


    }



}
