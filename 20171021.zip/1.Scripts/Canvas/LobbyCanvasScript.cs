﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LobbyCanvasScript : MonoBehaviour {



    private GameObject LobbyCanvas;

    private GameObject DungeonPanel;
    public GameObject[] Dungeonlist;

    // Use this for initialization
    void Awake()
    {
        LobbyCanvas = this.gameObject;
        DungeonPanel = LobbyCanvas.transform.Find("Panel_던전").gameObject;
        Dropdown_Dungeon = DungeonPanel.transform.Find("Dropdown").GetComponent<Dropdown>();
        hiredSoliderPanel = LobbyCanvas.transform.Find("Panel_용병고용소").gameObject;
        InventoryPanel = LobbyCanvas.transform.Find("Panel_인벤토리").gameObject;
        ShopPanel = LobbyCanvas.transform.Find("Panel_상점").gameObject; 
         SkillPanel = LobbyCanvas.transform.Find("Panel_스킬").gameObject;

    }

    public void Btn_GameStart()
    {

        AsyncOperation async = SceneManager.LoadSceneAsync("2.Ingame");
        async.allowSceneActivation = true;

    }
    //////////////////////////////
    ////// 던전 패널  ////////////
    ////////////////////////////

    public Dropdown Dropdown_Dungeon;

    public void Btn_DungeonPanel_Open()
    {

        for (int i = 0; i < Dungeonlist.Length; i++)
        {
            Dungeonlist[i].SetActive(false);
        }

        Dungeonlist[0].SetActive(true);


        DungeonPanel.SetActive(true);

    }
    public void Btn_DungeonPanel_Close()
    {
        DungeonPanel.SetActive(false);
    }
    public void Dropdown_ChangeDungeon()
    {
        for (int i = 0; i < Dungeonlist.Length; i++)
        {
            Dungeonlist[i].SetActive(false);
        }
        switch (Dropdown_Dungeon.value)
        {
            case 0:
                Debug.Log("0");
                Dungeonlist[0].SetActive(true);
                break;
            case 1:
                Debug.Log("1");
                Dungeonlist[1].SetActive(true);
                break;
            case 2:
                Debug.Log("2");
                Dungeonlist[2].SetActive(true);
                break;
            case 3:
                Debug.Log("3");
                Dungeonlist[3].SetActive(true);
                break;

        }



    }


    //////////////////////////////
    ////// 용병 고용소 패널  ////////////
    ////////////////////////////

    public GameObject hiredSoliderPanel;

    public void Btn_hiredsoldierPanel_open()
    {
        hiredSoliderPanel.SetActive(true);

    }
    public void Btn_hiredsoldierPanel_close()
    {

        hiredSoliderPanel.SetActive(false);

    }



    //////////////////////////////
    //////shop 패널  ////////////
    ////////////////////////////
    public GameObject ShopPanel;
    public void Btn_shopPanel_open()
    {
        ShopPanel.SetActive(true);

    }
    public void Btn_shopPanel_close()
    {
        ShopPanel.SetActive(false);

    }
    //////////////////////////////
    ////// Inventory 패널  ////////////
    ////////////////////////////
    public GameObject InventoryPanel;
    public void Btn_InventoryPanel_open()
    {
        InventoryPanel.SetActive(true);

    }
    public void Btn_InventoryPanel_close()
    {
        InventoryPanel.SetActive(false);

    }
    //////////////////////////////
    ////// skill 패널  ////////////
    ////////////////////////////
    public GameObject SkillPanel;
    public void Btn_SkillPanel_open()
    {
        SkillPanel.SetActive(true);

    }
    public void Btn_SkillPanel_close()
    {
        SkillPanel.SetActive(false);

    }


}
